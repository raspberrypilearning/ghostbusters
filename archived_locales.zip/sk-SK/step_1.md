Toto je staršia verzia **Lovci duchov**. V tomto momente stránka projektov neposkytuje najnovší obsah a užívateľské vlastnosti. Tie budú dočasne dostupné v [tomto formáte](images/Ghostbusters.pdf) pred ich archiváciou. 

Potrebujeme Vašu pomoc pri aktualizácii a preklade týchto projektov! Ak nám viete pomôcť, prosím [dajte nám vedieť](https://rpf.io/translators).
